module.exports = {
    error_code: 201,
    success_code: 200
}
