// var express = require('express');
// var router = express.Router();
// const userController = require('../controller/userController')
// /* GET users listing. */
// router.get('/', function(req, res, next) {
//   res.send('respond with a resource');
// });


// router.post('/signup', userController.signup)
// router.post('/login', userController.login)
// // router.post('/send-otp', userController.sendOtp)
// // router.post('/verify-otp', userController.verifyOtp)
// // router.post('/reset-password', userController.resetPassword)



// module.exports = router;